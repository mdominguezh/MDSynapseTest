#!/usr/bin/env bash
#
# Copyright (c) 2018 Microsoft Corp. All Rights Reserved.
#

current_userid=$(id -u)
if [ $current_userid -ne 0 ]; then
    echo "$(basename "$0") installation script requires superuser privileges to run"
    exit 1
fi

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

mkdir -p /usr/lib/azcopyv7
if [ ! $? -eq 0 ]; then
    echo "Failed to create folder for azcopy under /usr/lib"
    exit 1
fi

rsync -av --exclude startup --exclude installation $DIR/azcopy/* /usr/lib/azcopyv7

cp -f $DIR/azcopy/startup /usr/bin/azcopyv7
chmod a+x /usr/lib/azcopyv7/azcopy
chmod a+x /usr/bin/azcopyv7

if [ -d /etc/bash_completion.d ]; then
    cp $DIR/azcopy/azcopy_autocomplete /etc/bash_completion.d/azcopyv7
elif [ -d /usr/share/bash-completion/completions ]; then
    cp $DIR/azcopy/azcopy_autocomplete /usr/share/bash-completion/completions/azcopyv7
fi

if [ -f /etc/bash.bashrc ]; then
    source /etc/bash.bashrc
fi

